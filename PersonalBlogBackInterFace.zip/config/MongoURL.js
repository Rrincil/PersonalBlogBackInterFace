module.exports = {
  MongoURL :'mongodb+srv://one:13551802801shwy@cluster0.o5jfb.mongodb.net/MyPersonalBlog?retryWrites=true&w=majority'
} 